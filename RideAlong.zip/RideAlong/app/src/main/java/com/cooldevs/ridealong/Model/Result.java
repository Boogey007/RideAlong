package com.cooldevs.ridealong.Model;

public class Result { public String message_id; }
