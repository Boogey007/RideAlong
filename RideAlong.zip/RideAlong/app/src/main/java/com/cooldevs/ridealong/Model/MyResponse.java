package com.cooldevs.ridealong.Model;

import java.util.List;

public class MyResponse {

    public long multicase_id;

    public int success,failure, canonical_ids;
    public List<Result> result;
}
