package com.cooldevs.ridealong.Interface;

import android.view.View;

public interface IRecycItemListerner  {
    void onItemClickListener(View view, int position);
}
