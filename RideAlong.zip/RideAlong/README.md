## Ride Along

## RESOURCES
https://github.com/mapbox/mapbox-voice-runtime-demo/blob/master/app/src/main/res/drawable/ic_launcher_background.xml
https://easyappicon.com/
https://github.com/shobhitpuri/custom-google-signin-button
https://developer.android.com/guide/topics/ui/layout/recyclerview
https://github.com/ayush675/ServiceApp/blob/master/app/src/main/java/e/piyush/serviceapp/Servicess/MyFCMService.java -- notifications
https://www.youtube.com/watch?v=hyi4dLyPtpI&ab_channel=ProgrammerWorld                                               -- main start
https://www.youtube.com/watch?v=B_nWgtj25Rk&ab_channel=ProgrammingExperts                                            -- nav help and refer to for sending code 
https://pub.dev/documentation/flutter_android/latest/android_location/Location-class.html                            -- locations
https://developer.huawei.com/consumer/en/doc/HMS-Plugin-References-V1/hw_location-0000001050142357-V1                -- locations
https://stackoverflow.com/questions/17599450/how-to-inflate-view-inside-fragment                                     -- gallery fragment
https://firebase.google.com/docs/reference/js/firebase.database.Query                                                -- friendrequest
https://developers.google.com/android/reference/com/google/android/gms/location/LocationRequest                      -- locations
https://firebase.google.com/docs/auth/android/firebaseui                                                             -- signin w/ GSSO and firebase
https://stackoverflow.com/questions/57079273/android-studios-default-mapsactivity-code-does-not-work                 -- tracking
https://stackoverflow.com/questions/61972598/reference-firebasedatabase-getinstance-getreferenceusers-childuserid    -- user profile


## SETUP
1. Connect Firebase with google-services.json file
2. Connect with your Google Maps api with pgoogle_maps_api.xml
3. Connect with Firebase Cloud Messaging with Authorization:key= longkey

## Features
Google login/Normal Login
User profile update
Search new people
Add/remove friends
Locate friends and your position

TODO: VEHICLE TRACKING
TODO: SPRINT 1 FINISH
TODO: LOGIN BUTTON
TODO: SIGNUP BUTTON
TODO: SECRET CODE

cant figure out gitignore file so if you have a ton of stuff in commit log run this in cmd prompt in the directory of proj.
git rm --cached app/build/ -r && git rm --cached .gradle -r